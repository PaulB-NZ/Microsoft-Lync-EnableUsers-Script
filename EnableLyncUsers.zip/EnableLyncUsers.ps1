
<#
.SYNOPSIS
    The script enables users for Lync based on a csv input file. It also assigns all the relevant policies as well as assigning the line uri's. 

.DESCRIPTION
    	
	This script will run through a csv input file and generate the required commands to enable and assign users to Lync.
	The script will also report on any users in the csv file that were not enabled for Lync.
    Each user in the csv file will need a valid AD user account.
	The csv file column headers are used as variables so need to be unchanged.
	Edit the variables to match your environment
	The scipt uses the users email address as a sip address

.Format
	The csv file will need the following column headers:-
	ADUsername,LineUri,LocationPolicy,DialPlanPolicy,VoicePolicy,ConferencingPolicy,ExternalPolicy,ClientPolicy,MobilityPolicy,Pool
	If any policy is to remain as default then simply edit out the policy in the script below, the labels provide for easy recognition within the script.
    Make sure that the data within each row matches alreadt configured, valid policies

.Example of input file format
ADUsername,LineUri,LocationPolicy,DialPlanPolicy,VoicePolicy,ConferencingPolicy,ExternalPolicy,ClientPolicy,MobilityPolicy,Pool
PanP,+6499702700,Auckland,Auckland_Dial_Plan,NZ_International,Audio_Only,Full External_Access,Photo_Control,lyncpool01.lyncsorted.co.nz
	
.NOTES
    File Name: EnableLyncusers.ps1
	Version: 0.4
	Last Update: 17-May-2014
    Author: Paul Bloem, http://ucsorted.com
    The script is provided �AS IS� with no guarantees, no warranties, USE AT YOUR OWN RISK.    
#>
#Variables - EDIT THESE 2 FILE PATHS TO MATCH YOUR OWN
# $File is the path and file name of the csv file
# $log is the log file
$File = "C:\LyncSupport\Scripts\EnableLyncUsers.csv"
$Log = New-Item -ItemType File -Path "C:\LyncSupport\Scripts\enableuserlog.txt" -Force

#Import csv
$usercsv = Import-Csv -path $file -Delimiter ','

#Check if user file is empty.
if ($Usercsv -eq $null)
{
	 write-host "No Users Found in the Input File"
	 exit 0
}

#Get the number of users in CSV file and begin proccessing.

$count = $Usercsv | Measure-Object | Select-Object -expand count

Write-Host "Found " $count "Users to enable for Lync."
Write-Host "Enabling Users.....`n"
$index = 1

ForEach ($user in $usercsv)

{

	Write-Host "Enabling User " $index " of " $count
		$Fullname = $User.ADUsername
		$aduser = get-csaduser -Identity $Fullname

	#Check if the user is valid in AD.  Report to the log file if they are NOT.
	if ($aduser -eq $null) {
		$notinad = $true
		Write-Host "User " $Fullname " is not a valid AD user.  Please check the user name for spelling typos, etc." -Foregroundcolor Red
		Add-Content -Path $Log -Value "$($Fullname) is not a valid AD user.  Please check the user name for spelling typos, etc."
			}

	else {
		$notinad = $false
	}

#If user is a valid AD user, check to see if the user is already enabled for Lync and report to the log file if the user is enabled.
	if ($aduser.Enabled) {
		Write-Host $User.ADUsername"is already enabled for Lync, skipping."  -Foregroundcolor Yellow
		Add-Content -Path $Log -Value "$($Fullname) is already enabled for Lync."
			}		

	#If User is not enabled for Lync
	else {
		Write-Host "Enabling user " $User.ADUsername -Foregroundcolor Green
                Enable-CsUser -Identity $User.ADUsername -RegistrarPool $user.pool -SipAddresstype emailaddress
					#Check if the previous command failed.  If it did then write that to the log file.
						if(!$?) {
							Add-Content -Path $Log -Value "$($Fullname) not enabled.  $(Get-Date)$($error[0])"
			continue
					}
		#Enable Lync user for Enterprise Voice and Add the Line URI
				Set-csuser -identity $User.ADUsername -enterprisevoiceenabled $true -lineuri $user.LineURI
					#Check if previous command failed.  If it did then write that to the log file.
						if(!$?) {
							Add-Content -Path $Log -Value "$($Fullname) not enabled.  $(Get-Date)$($error[0])"
			continue
					}
		#Assign the defined CSClientPolicy
				Grant-csclientpolicy -Identity $User.ADUsername -PolicyName $user.clientpolicy
					#Check if previous command failed.  If it did then write that to the log file.
						if(!$?) {
							Add-Content -Path $Log -Value "$($Fullname) not enabled.  $(Get-Date)$($error[0])"
			continue
					}
		#Assign the defined Conferencing Policy
				Grant-csconferencingpolicy -Identity $User.ADUsername -PolicyName $user.conferencepolicy
					#Check if previous command failed.  If it did then write that to the log file.
						if(!$?) {
							Add-Content -Path $Log -Value "$($Fullname) not enabled.  $(Get-Date)$($error[0])"
			continue
					}
		#Assign the defined Dial Plan
				Grant-CsDialPlan -Identity $User.ADUsername -PolicyName $user.DialPlanpolicy
					#Check if previous command failed.  If it did then write that to the log file.
						if(!$?) {
							Add-Content -Path $Log -Value "$($Fullname) not enabled.  $(Get-Date)$($error[0])"
			continue
					}
		#Assign the defined Voice Policy
				Grant-CsVoicePolicy -Identity $User.ADUsername -PolicyName $user.Voicepolicy
					#Check if previous command failed.  If it did then write that to the log file.
						if(!$?) {
							Add-Content -Path $Log -Value "$($Fullname) not enabled.  $(Get-Date)$($error[0])"
			continue
					}
		#Assign the defined External Access Policy
				grant-csexternalaccesspolicy -Identity $User.ADUsername -PolicyName $user.externalaccesspolicy
					#Check if previous command failed.  If it did then write that to the log file.
						if(!$?) {
							Add-Content -Path $Log -Value "$($Fullname) not enabled.  $(Get-Date)$($error[0])"
			continue
		 			}
		#Assign the defined Mobility Policy
				grant-csmobilitypolicy -Identity $User.ADUsername -PolicyName $user.mobilitypolicy
					#Check if previous command failed.  If it did then write that to the log file.
						if (!$?)
		{
			Add-Content -Path $Log -Value "$($Fullname) not enabled.  $(Get-Date)$($error[0])"
			continue
		}
	}
	$index++
}

Write-Host "Provisioning of users to Lync from CSV has completed!"
Write-Host ""
Write-Host ""
Write-Host ""

#Update the AddressBook Service
sleep -seconds 10
update-csuserdatabase -verbose





